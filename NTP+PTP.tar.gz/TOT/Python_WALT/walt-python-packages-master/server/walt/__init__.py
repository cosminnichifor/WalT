# walt is a "namespace namespace", shared by walt-client, walt-server, walt-node
# see: http://pythonhosted.org/setuptools/setuptools.html#namespace-packages
__import__('pkg_resources').declare_namespace(__name__)
