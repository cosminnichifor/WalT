This is the client package of WalT (Wireless Testbed).
See https://github.com/drakkar-lig/walt-python-packages for more info.
