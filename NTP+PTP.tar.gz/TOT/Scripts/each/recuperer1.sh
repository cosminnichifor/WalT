#!/bin/bash

conv_date() { 
	in_date=$1
	set -- $(echo $in_date | tr '.' ' ')
	echo "$(date +%s -d "$1")$2"
}

FILE=/home/cosmin/Desktop/Loggings/ping_pong_1.txt

grep -E '(request)' $FILE | while read tslog logstream arrow d IP a1 fleche a2 IC ec req ceva key rest ; do  echo "$(conv_date $d) $key"; done > /home/cosmin/Desktop/Loggings/log_rpi_1.txt
