#!/bin/bash
# Get the local precise time on all devices connected at once

walt node shell rpi-D106-1
echo "rpi-D106-1's time is : $(date --rfc-3339=ns)" >> timing.txt
echo "" >> timing.txt
echo "" >> timing.txt
