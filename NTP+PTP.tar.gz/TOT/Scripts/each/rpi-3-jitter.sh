#!/bin/bash
# Get the offset timings for all the nodes of the network
	
echo "rpi-D106-3 has a total drift jitter [in miliseconds] : " >> offsets.txt
walt node shell rpi-D106-3 << ETIQUETTE
service ntp restart
walt-monitor /usr/local/bin/offset.sh
ETIQUETTE
exit
/home/cosmin/Desktop/Scripts/print.sh >> offsets.txt &
sleep 3
killall print.sh
echo "" >> offsets.txt
