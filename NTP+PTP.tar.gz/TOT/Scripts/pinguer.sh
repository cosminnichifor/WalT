#!/bin/bash

ping -I wlan0 -c 10 -b 192.168.42.255  | while read pong; do echo "$(date --rfc-3339=ns): $pong"; done > ping_log.txt
