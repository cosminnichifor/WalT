#!/bin/bash


# Already Done => Short hours logging files were created (log_rpi_1.txt & log_rpi_2.txt)

# /home/cosmin/Desktop/Scripts/each/recuperer1.sh > /home/cosmin/Desktop/Loggings/log_rpi_1.txt
# /home/cosmin/Desktop/Scripts/each/recuperer2.sh > /home/cosmin/Desktop/Loggings/log_rpi_2.txt

# -----------------------------------------------------------------------------------------------
wait

FILE_LOG_1=/home/cosmin/Desktop/Loggings/log_rpi_1.txt
FILE_LOG_2=/home/cosmin/Desktop/Loggings/log_rpi_2.txt

# Getting the total number of lines of each file of logging
WC_1=$(wc -l $FILE_LOG_1)
LINES_1=${WC_1:0:6}
WC_2=$(wc -l $FILE_LOG_2)
LINES_2=${WC_2:0:6}

# Getting the minimum of those two numbers (loggings have different lenghts)
if [ $LINES_1 -gt $LINES_2 ]
then
	MAX=$LINES_2
else
	MAX=$LINES_1
fi

# Calculating the timestamp difference for each line and 
# print them in a third file (/home/cosmin/Desktop/Loggings/logging_results.txt)
TARGET=/home/cosmin/Desktop/Loggings/logging_results.txt

COUNTER="1"

echo "" > $TARGET

while [ $COUNTER -le $MAX ]
do
	LINE_1=$(head -$COUNTER $FILE_LOG_1 | tail -1)
	LINE_2=$(head -$COUNTER $FILE_LOG_2 | tail -1)

	# XX:--:--.------
	HOUR1=${LINE_1:0:2}
	if [ ${HOUR1:0:1} -eq "0" ]
	then
		HOUR1=${HOUR1:1:1}
	fi
	HOUR2=${LINE_2:0:2}
	if [ ${HOUR2:0:1} -eq "0" ]
	then
		HOUR2=${HOUR2:1:1}
	fi	

	# --:XX:--.------
	MINS1=${LINE_1:3:2}
	if [ ${MINS1:0:1} -eq "0" ]
	then
		MINS1=${MINS1:1:1}
	fi
	MINS2=${LINE_2:3:2}
	if [ ${MINS2:0:1} -eq "0" ]
	then
		MINS2=${MINS2:1:1}
	fi

	# --:--:XX.------
	SEC1=${LINE_1:6:2}
	if [ ${SEC1:0:1} -eq "0" ]
	then
		SEC1=${SEC1:1:1}
	fi
	SEC2=${LINE_2:6:2}
	if [ ${SEC2:0:1} -eq "0" ]
	then
		SEC2=${SEC2:1:1}
	fi

	# --:--:--.XXXXXX
	SIX1=${LINE_1:9:6}
	if [ ${SIX1:0:1} -eq "0" ]
	then
		SIX1=${SIX1:1:5}
	fi
	if [ ${SIX1:0:1} -eq "0" ]
	then
		SIX1=${SIX1:1:4}
	fi
	if [ ${SIX1:0:1} -eq "0" ]
	then
		SIX1=${SIX1:1:3}
	fi
	if [ ${SIX1:0:1} -eq "0" ]
	then
		SIX1=${SIX1:1:2}
	fi
	if [ ${SIX1:0:1} -eq "0" ]
	then
		SIX1=${SIX1:1:1}
	fi
	
	SIX2=${LINE_2:9:6}
	if [ ${SIX2:0:1} -eq "0" ]
	then
		SIX2=${SIX2:1:5}
	fi
	if [ ${SIX2:0:1} -eq "0" ]
	then
		SIX2=${SIX2:1:4}
	fi
	if [ ${SIX2:0:1} -eq "0" ]
	then
		SIX2=${SIX2:1:3}
	fi
	if [ ${SIX2:0:1} -eq "0" ]
	then
		SIX2=${SIX2:1:2}
	fi
	if [ ${SIX2:0:1} -eq "0" ]
	then
		SIX2=${SIX2:1:1}
	fi

	if [ $HOUR1 -gt $HOUR2 ]
	then
		MINS1="60"
		HOUR1=$[$HOUR1-1]
	else
		MINS2="60"
		HOUR2=$[$HOUR2-1]
	fi

	if [ $MINS1 -gt $MINS2 ]
	then
		SEC1="60"
		MINS1=$[$MINS1-1]
	else
		SEC2="60"
		MINS2=$[$MINS2-1]
	fi

	#if [ $SEC1 -gt $SEC2 ]
	#then
		#SIX1=$[$SIX1+1000000]
		#SEC1=$[$SEC1-1]
	#else
		#SIX2=$[$SIX2+1000000]
		#SEC2=$[$SEC2-1]
	#fi

	if [ $SIX1 -gt $SIX2 ]
	then
		DIFF=$[$SIX1-$SIX2]
	else
		DIFF=$[$SIX2-$SIX1]
	fi

	LENGTH=${#DIFF}
	if [ $LENGTH -eq "0" ]
	then
		echo "000000" >> $TARGET
	fi
	if [ $LENGTH -eq "1" ]
	then
		echo "00000$DIFF" >> $TARGET
	fi
	if [ $LENGTH -eq "2" ]
	then
		echo "0000$DIFF" >> $TARGET
	fi
	if [ $LENGTH -eq "3" ]
	then
		echo "000$DIFF" >> $TARGET
	fi
	if [ $LENGTH -eq "4" ]
	then
		echo "00$DIFF" >> $TARGET
	fi
	if [ $LENGTH -eq "5" ]
	then
		echo "0$DIFF" >> $TARGET
	fi
	if [ $LENGTH -eq "6" ]
	then
		echo "$DIFF" >> $TARGET
	fi

	COUNTER=$[$COUNTER+1]
done
