#!/bin/bash
#Script to reboot a switch containing Raspberry Pi 's

for i in $1 $2 $3 $4 $5
do
	walt node reboot $i &
done
echo