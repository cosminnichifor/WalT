#!/bin/bash
# First script to run some statistics

function connected() {
        echo "I went online at this moment : $(date --rfc-3339=ns)"
}

#-----------------------------------UNUSED---------------------------------
        # fifo="fifo";

        # This will be used by netcat in order to write messages
        # [ -p $fifo ] || mkfifo $fifo;

        # Connect to the server using name resolution provided by avahi
        # netcat rpi-D106-2-Ping.local 12345 < $fifo | connected 1> $fifo &
#--------------------------------------------------------------------------

connected

# Print it on stderr in order to see it. We could have use stdout
# on this one.
echo 'Sync in progress ...' >&2
