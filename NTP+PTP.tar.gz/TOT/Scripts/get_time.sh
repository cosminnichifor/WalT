#!/bin/bash
# Get the local precise time on all devices connected at once

echo "This file shows the local time on all devices." > timing.txt
echo "" >> timing.txt
echo "" >> timing.txt

./each/rpi-1.sh &
./each/rpi-2.sh &
./each/rpi-3.sh &
./each/rpi-4.sh &
./each/rpi-5.sh &

wait
echo "All 4 complete ... [PASSED]"
