#!/bin/bash
# Script to wait the reception of a file from a server
# Script to be launched on a client machine

# 129.88.49.129 is the IP of the server in this case
# Listening on the port n. 12345
# NetCat trasmits a file called offsets.txt by a script called send.sh
# Server sends by default this file pb the port n. 12345
# The arg1 ($1) is the IP adress of the server
# The arg2 ($2) is the port number

nc 129.88.49.129 12345 > offsets.txt

# Test if the file was successfully sent or not
FICHIER="./offsets.txt"
while true;
do
	if [ -f "$FICHIER" ]
	then
		echo "( $FICHIER ) has been successfully delivered"
		echo "from IP : ( 129.88.49.129 ) and by port n. ( 12345 )"
		echo "at this moment : $(date --rfc-3339=ns) [local rpi time]"
		echo "[SUCCESS]"
		echo ""
		# Quit the TRUE loop
		break
	else
		echo "Still waiting for ( $FICHIER ) to be sent ..."
	fi
done

