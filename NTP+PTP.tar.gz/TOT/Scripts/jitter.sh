#!/bin/bash
# Get the offset timings for all the nodes of the network

echo "This file contains the jitters (timing lags) for all the devices of the sub-network." > offsets.txt
echo "" >> offsets.txt
echo "$(date --rfc-3339=ns)" >> offsets.txt
echo "" >> offsets.txt

./each/rpi-1-jitter.sh
sleep 4
wait
./each/rpi-2-jitter.sh
sleep 4
wait
./each/rpi-3-jitter.sh
sleep 4
wait
./each/rpi-4-jitter.sh
sleep 4
wait

echo $?
