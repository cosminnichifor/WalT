#!/bin/bash

# Launching remotely the script to receive
walt node shell rpi-D106-1 & << ETIQUETTE
/usr/local/bin/ponguer.sh
ETIQUETTE
exit

# Launching remotely the script to receive
walt node shell rpi-D106-2 & << ETIQUETTE2
/usr/local/bin/ponguer.sh
ETIQUETTE2
exit

# Launching remotely the script to receive
walt node shell rpi-D106-4 & << ETIQUETTE3
/usr/local/bin/pinguer.sh
ETIQUETTE3
exit

wait

exit 0
