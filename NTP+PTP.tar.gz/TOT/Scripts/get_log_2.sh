#!/bin/bash

walt log show | grep rpi-D106-2 > /home/cosmin/Desktop/Loggings/ping_pong_2.txt
