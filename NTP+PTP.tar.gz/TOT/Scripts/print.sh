#!/bin/bash

walt log show
