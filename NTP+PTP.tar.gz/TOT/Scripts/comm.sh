#!/bin/bash

# /home/cosmin/Desktop/Scripts/shorten_logs.sh

wait

cp /home/cosmin/Desktop/Loggings/log_rpi_1.txt /home/cosmin/Desktop/Loggings/log_rpi_1_back.txt
cp /home/cosmin/Desktop/Loggings/log_rpi_2.txt /home/cosmin/Desktop/Loggings/log_rpi_2_back.txt

FILE_LOG_1=/home/cosmin/Desktop/Loggings/log_rpi_1_back.txt
FILE_LOG_2=/home/cosmin/Desktop/Loggings/log_rpi_2_back.txt

# Getting the total number of lines of each file of logging

LINES_1=$(wc -l $FILE_LOG_1 | while read number rest_of_line ; do echo $number ; done)
LINES_2=$(wc -l $FILE_LOG_2 | while read number rest_of_line ; do echo $number ; done)

# Getting the minimum of those two numbers (loggings have different lenghts)
if [ "$LINES_1" -gt "$LINES_2" ]
then
	MIN=$LINES_2
else
	MIN=$LINES_1
fi

# Calculating the timestamp difference for each line and 
# print them in a third file (/home/cosmin/Desktop/Loggings/logging_results.txt)
TARGET=/home/cosmin/Desktop/Loggings/logging_results.txt
AUX=/home/cosmin/Desktop/Loggings/aux.txt

COUNTER="1"
PIP="1"

echo "The following numbers represent the time difference in MICROSECONDS" > $TARGET 
echo "between the reception ACK of rpi-D106-1 and rpi-D106-2 :" >> $TARGET
echo "" >> $TARGET

while [ $COUNTER -le $MIN ]
do
	TIME_1=$(sed $COUNTER!d $FILE_LOG_1 | while read time idf ; do echo "$time" ; done)
	IDF_1=$(sed $COUNTER!d $FILE_LOG_1 | while read time idf ; do echo "$idf" ; done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')

	cat $FILE_LOG_2 | grep -sw "^.\{17\}$IDF_1" > $AUX

	if [ $? -eq "0" ]
	then	
		TIME_2=$(sed $PIP!d $AUX | while read time idf ; do echo "$time" ; done)
		IDF_2=$(sed $PIP!d $AUX | while read time idf ; do echo "$idf" ; done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')

		#echo "{$TIME_1 ; $IDF_1 } === {$IDF_2 ; $TIME_2}"

		if [ $IDF_1 -eq $IDF_2 ]
		then 	
			DIFF=$[$TIME_1-$TIME_2]
			echo "$DIFF" >> $TARGET
		fi
	fi
	touch $AUX

	sed -i '1d' $FILE_LOG_2

	COUNTER=$[$COUNTER+1]
done

rm $AUX
rm $FILE_LOG_1
rm $FILE_LOG_2
