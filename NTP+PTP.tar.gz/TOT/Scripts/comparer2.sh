#!/bin/bash

/home/cosmin/Desktop/Scripts/shorten_logs.sh

wait

FILE_LOG_1=/home/cosmin/Desktop/Loggings/log_rpi_1.txt
FILE_LOG_2=/home/cosmin/Desktop/Loggings/log_rpi_2.txt

# Getting the total number of lines of each file of logging

LINES_1=$(wc -l $FILE_LOG_1 | while read number rest_of_line ; do echo $number ; done)
LINES_2=$(wc -l $FILE_LOG_2 | while read number rest_of_line ; do echo $number ; done)

# Getting the minimum of those two numbers (loggings have different lenghts)
if [ "$LINES_1" -gt "$LINES_2" ]
then
	MIN=$LINES_2
else
	MIN=$LINES_1
fi

# Calculating the timestamp difference for each line and 
# print them in a third file (/home/cosmin/Desktop/Loggings/logging_results.txt)
TARGET=/home/cosmin/Desktop/Loggings/logging_results.txt

COUNTER_1="1"
COUNTER_2="1"

echo "The following numbers represent the time difference in MICROSECONDS" > $TARGET 
echo "between the reception ACK of rpi-D106-1 and rpi-D106-2 :" >> $TARGET
echo "" >> $TARGET

while [ $COUNTER_1 -le $MIN ] && [ $COUNTER_2 -le $MIN ]
do
	TIME_1=$(sed $COUNTER_1!d $FILE_LOG_1 | while read time idf ; do echo "$time" ; done)
	IDF_1=$(sed $COUNTER_1!d  $FILE_LOG_1 | while read time idf ; do echo "$idf" ; done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')

	TIME_2=$(sed $COUNTER_2!d  $FILE_LOG_2 | while read time idf ; do echo "$time" ; done)
	IDF_2=$(sed $COUNTER_2!d  $FILE_LOG_2 | while read time idf ; do echo "$idf" ; done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')

	if [ $IDF_1 -eq $IDF_2 ]
	then 
		# Set or Unset the absolute value
		#if [ $TIME_1 -gt $TIME_2 ]
		#then
			#DIFF=$[$TIME_1-$TIME_2]
		#else
			DIFF=$[$TIME_2-$TIME_1]
		#fi
		# ABS SET TO UNABLE

	 	echo "$DIFF" >> $TARGET
	else
		COUNTER_1_AUX=$[$COUNTER_1+1]
		IDF_1_AUX=$(sed $COUNTER_1_AUX!d  $FILE_LOG_1 | while read time idf ; do echo "$idf" ; done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')
		if [[ -z "$IDF_1_AUX" ]]
		then
			break
		fi
		if [ $IDF_1_AUX -eq $IDF_2 ]
		then
			COUNTER_1=$COUNTER_1_AUX
		else
			COUNTER_2_AUX=$[$COUNTER_2+1]
			IDF_2_AUX=$(sed $COUNTER_2_AUX!d  $FILE_LOG_2 | while read time idf ; do echo "$idf" ; done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')
			if  [[ -z "$IDF_2_AUX" ]]
			then
				break
			fi
			if [ $IDF_1 -eq $IDF_2_AUX ]
			then
				COUNTER_2=$COUNTER_2_AUX
			fi
		fi
	fi
	COUNTER_1=$[$COUNTER_1+1]
	COUNTER_2=$[$COUNTER_2+1]
done
