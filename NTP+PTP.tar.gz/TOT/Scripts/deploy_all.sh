#!/bin/bash
#Script to deploy a given image on all Raspberry Pi 's

for i in $1 $2 $3 $4
do
	walt node deploy $i $5 &
done
echo $?