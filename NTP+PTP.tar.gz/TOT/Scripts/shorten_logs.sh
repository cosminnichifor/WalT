#!/bin/bash

/home/cosmin/Desktop/Scripts/each/recuperer1.sh > /home/cosmin/Desktop/Loggings/log_rpi_1.txt
/home/cosmin/Desktop/Scripts/each/recuperer2.sh > /home/cosmin/Desktop/Loggings/log_rpi_2.txt
