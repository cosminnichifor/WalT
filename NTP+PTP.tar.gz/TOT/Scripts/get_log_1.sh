#!/bin/bash

walt log show | grep rpi-D106-1 > /home/cosmin/Desktop/Loggings/ping_pong_1.txt
