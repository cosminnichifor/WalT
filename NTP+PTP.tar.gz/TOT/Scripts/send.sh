#!/bin/bash

# Script to send a file to RPis
# The arg1 ($1) refers to the port number (usually 12345)

echo "The file has been received by the two RPi devices at the following moments :" > receive_time.txt
echo "" >> receive_time.txt

# Open the UDP tunnel connection
nc -l 12345 < offsets.txt &
# Sending *offsets.txt* file to the tunnel ...

# Launching the Log Show client
/home/cosmin/Desktop/Scripts/print.sh >> receive_time.txt &

# Launching remotely the script to receive the file
walt node shell rpi-D106-3 & << ETIQUETTE
/usr/local/bin/receive.sh 129.88.49.129 12345
ETIQUETTE
exit

# Doing the same thing for the second RPi
walt node shell rpi-D106-4 & << ETIQUETTE2
/usr/local/bin/receive.sh 129.88.49.129 12345
ETIQUETTE2
exit

wait
sleep 3
killall print.sh

killall nc

echo "" >> receive_time.txt
echo $?
