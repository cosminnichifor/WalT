#!/bin/bash

walt node shell rpi-D106-2 << RPI2
walt-monitor /usr/local/bin/ntpq.sh
RPI2
exit
