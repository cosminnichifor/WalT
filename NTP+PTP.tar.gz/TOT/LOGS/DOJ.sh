#!/bin/bash

TARGET="/home/nichifoc/LOGS/DOJ.txt"
COUNTER=1850
while [ "$COUNTER" -ne "0" ]
do
	/home/nichifoc/LOGS/doj1.sh &
	wait
	/home/nichifoc/LOGS/doj2.sh &
	wait	
	/home/nichifoc/LOGS/doj3.sh &
	wait
	/home/nichifoc/LOGS/doj4.sh &
	wait

	sleep 30
	COUNTER=$[$COUNTER-1]
done
