#!/bin/bash

walt node shell rpi-D106-4 << RPI4
walt-monitor /usr/local/bin/ntpq.sh
RPI4
exit
