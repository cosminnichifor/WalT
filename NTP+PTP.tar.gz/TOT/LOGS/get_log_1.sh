#!/bin/bash

walt log show | grep rpi-D106-1 > /home/nichifoc/LOGS/ping_pong_1.txt
