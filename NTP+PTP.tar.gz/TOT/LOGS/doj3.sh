#!/bin/bash

walt node shell rpi-D106-3 << RPI3
walt-monitor /usr/local/bin/ntpq.sh
RPI3
exit
