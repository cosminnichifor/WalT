#!/bin/bash

walt log show | grep rpi-D106-3 > /home/nichifoc/LOGS/ping_pong_3.txt
