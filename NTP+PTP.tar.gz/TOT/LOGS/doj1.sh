#!/bin/bash

walt node shell rpi-D106-1 << RPI1
walt-monitor /usr/local/bin/ntpq.sh
RPI1
exit
