#!/bin/bash

/home/cosmin/Desktop/Aquarium/recuperer1.sh > /home/cosmin/Desktop/Aquarium/log_rpi_1.txt
/home/cosmin/Desktop/Aquarium/recuperer2.sh > /home/cosmin/Desktop/Aquarium/log_rpi_2.txt
/home/cosmin/Desktop/Aquarium/recuperer3.sh > /home/cosmin/Desktop/Aquarium/log_rpi_3.txt
