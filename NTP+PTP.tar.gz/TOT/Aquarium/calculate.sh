#!/bin/bash

/home/cosmin/Desktop/Aquarium/short_logs.sh

echo "Shorting logs ... [DONE]"

wait

FILE_LOG_1=/home/cosmin/Desktop/Aquarium/log_rpi_1.txt
FILE_LOG_2=/home/cosmin/Desktop/Aquarium/log_rpi_2.txt
FILE_LOG_3=/home/cosmin/Desktop/Aquarium/log_rpi_3.txt

# Getting the total number of lines of each file of logging

LINES_1=$(wc -l $FILE_LOG_1 | while read number rest_of_line ; do echo $number ; done)
LINES_2=$(wc -l $FILE_LOG_2 | while read number rest_of_line ; do echo $number ; done)
LINES_3=$(wc -l $FILE_LOG_3 | while read number rest_of_line ; do echo $number ; done)

# Getting the minimum of those two numbers (loggings have different lenghts)
if [ "$LINES_1" -gt "$LINES_2" ]
then
	if [ "$LINES_2" -gt "$LINES_3" ]
	then 
		MIN=$LINES_3
	else
		MIN=$LINES_2
	fi
else
	if [ "$LINES_1" -gt "$LINES_3" ]
	then 
		MIN=$LINES_3
	else
		MIN=$LINES_1
	fi
fi

# Calculating the timestamp difference for each line and 
# print them in a third file (/home/cosmin/Desktop/Aquarium/logging_results.txt)
TARGET_1_2=/home/cosmin/Desktop/Aquarium/logging_results_1_2.txt
AUX_1_2=/home/cosmin/Desktop/Aquarium/aux12.txt
TARGET_1_3=/home/cosmin/Desktop/Aquarium/logging_results_1_3.txt
AUX_1_3=/home/cosmin/Desktop/Aquarium/aux13.txt
MATH=/home/cosmin/Desktop/Aquarium/math_trace.txt

COUNTER="1"
PIP="1"

echo "The following numbers represent the time difference in MICROSECONDS" > $TARGET_1_2 
echo "between the reception ACK of rpi-D106-1 and rpi-D106-2 :" >> $TARGET_1_2
echo "" >> $TARGET_1_2

echo "The following numbers represent the time difference in MICROSECONDS" > $TARGET_1_3 
echo "between the reception ACK of rpi-D106-1 and rpi-D106-3 :" >> $TARGET_1_3
echo "" >> $TARGET_1_3

echo $MIN > $MATH
while [ $COUNTER -le $MIN ]
do
	TIME_1=$(sed $COUNTER!d $FILE_LOG_1 | while read time idf ; do echo "$time" ; done)
	IDF_1=$(sed $COUNTER!d $FILE_LOG_1 | while read time idf ; do echo "$idf" ; 
		done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')

	cat $FILE_LOG_2 | grep -sw "^.\{17\}$IDF_1" > $AUX_1_2
	if [ $? -eq "0" ]
	then	
		TIME_2=$(sed $PIP!d $AUX_1_2 | while read time idf ; do echo "$time" ; done)
		IDF_2=$(sed $PIP!d $AUX_1_2 | while read time idf ; do echo "$idf" ; 
			done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')

		if [ $IDF_1 -eq $IDF_2 ]
		then 	
			DIFF=$[$TIME_1-$TIME_2]
			echo "$DIFF" >> $TARGET_1_2
			echo "--- between 1 and 2 --- {$TIME_1 ; $IDF_1 } === {$IDF_2 ; $TIME_2} ==> $TIME_1 - $TIME_2 = $DIFF" >> $MATH
		fi
	fi

	cat $FILE_LOG_3 | grep -sw "^.\{17\}$IDF_1" > $AUX_1_3
	if [ $? -eq "0" ]
	then	
		TIME_3=$(sed $PIP!d $AUX_1_3 | while read time idf ; do echo "$time" ; done)
		IDF_3=$(sed $PIP!d $AUX_1_3 | while read time idf ; do echo "$idf" ; 
			done | tr '\n' ' ' | sed -e 's/[^0-9]/ /g' -e 's/^ *//g' -e 's/ *$//g' | tr -s ' ' | sed 's/ /\n/g')

		if [ $IDF_1 -eq $IDF_3 ]
		then 	
			DIFF=$[$TIME_1-$TIME_3]
			echo "$DIFF" >> $TARGET_1_3
			echo "+++ between 1 and 3 +++ {$TIME_1 ; $IDF_1 } === {$IDF_3 ; $TIME_3} ==> $TIME_1 - $TIME_3 = $DIFF" >> $MATH
		fi
	fi

	echo "" >> $MATH

	touch $AUX_1_2
	touch $AUX_1_3

	COUNTER=$[$COUNTER+1]
done

rm $AUX_1_2
rm $AUX_1_3
