#!/bin/bash

# scp nichifoc@ralik.imag.fr:/home/nichifoc/LOGS/DOJ.txt /home/cosmin/Desktop/Aquarium/DOJ.txt

INPUT="/home/cosmin/Desktop/Aquarium/min_max_poll.txt"
AUX="/home/cosmin/Desktop/Aquarium/aux.txt"
JOD1="/home/cosmin/Desktop/Aquarium/JOD1.txt"
JOD2="/home/cosmin/Desktop/Aquarium/JOD2.txt"
JOD3="/home/cosmin/Desktop/Aquarium/JOD3.txt"
JOD4="/home/cosmin/Desktop/Aquarium/JOD4.txt"

> $JOD1
> $JOD2
> $JOD3
> $JOD4
> $AUX

LINES=$(wc -l $INPUT | while read cifra nume ; do echo "$cifra" ; done)

COUNTER="1"

grep "rpi-D106-1" $INPUT > $AUX

while [ $COUNTER -le $LINES ]
do
	sed $COUNTER!d $AUX | while read ora info arrow a b c ; do echo "$a $b $c"; done | head -1 >> $JOD1
	COUNTER=$[$COUNTER+1]
done


COUNTER="1"

grep "rpi-D106-2" $INPUT > $AUX

while [ $COUNTER -le $LINES ]
do
	sed $COUNTER!d $AUX | while read ora info arrow a b c ; do echo "$a $b $c"; done | head -1 >> $JOD2
	COUNTER=$[$COUNTER+1]
done


COUNTER="1"

grep "rpi-D106-3" $INPUT > $AUX

while [ $COUNTER -le $LINES ]
do
	sed $COUNTER!d $AUX | while read ora info arrow a b c ; do echo "$a $b $c"; done | head -1 >> $JOD3
	COUNTER=$[$COUNTER+1]
done


COUNTER="1"

grep "rpi-D106-4" $INPUT > $AUX

while [ $COUNTER -le $LINES ]
do
	sed $COUNTER!d $AUX | while read ora info arrow a b c ; do echo "$a $b $c"; done | head -1 >> $JOD4
	COUNTER=$[$COUNTER+1]
done
rm $AUX
