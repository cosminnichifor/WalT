#!/bin/bash

JOD1="/home/cosmin/Desktop/Aquarium/JOD1.txt"
JOD2="/home/cosmin/Desktop/Aquarium/JOD2.txt"
JOD3="/home/cosmin/Desktop/Aquarium/JOD3.txt"
JOD4="/home/cosmin/Desktop/Aquarium/JOD4.txt"

D1="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/delay_1.txt"
D2="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/delay_2.txt"
D3="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/delay_3.txt"
D4="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/delay_4.txt"

O1="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/offset_1.txt"
O2="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/offset_2.txt"
O3="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/offset_3.txt"
O4="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/offset_4.txt"

J1="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/jitter_1.txt"
J2="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/jitter_2.txt"
J3="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/jitter_3.txt"
J4="/home/cosmin/Desktop/Aquarium/delay_offset_jitter/jitter_4.txt"

i="1"
while [ $i -lt "5" ]
do
	A="JOD${i}"
	B="D${i}"
	C="O${i}"
	D="J${i}"

	cat ${!A} | while read a b c; do echo "$a"; done >  ${!B}
	cat ${!A} | while read a b c; do echo "$b"; done >  ${!C}
	cat ${!A} | while read a b c; do echo "$c"; done >  ${!D}

	i=$[$i+1]
done
