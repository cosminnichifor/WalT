#!/bin/bash
conv_date() { 
	in_date=$1
	set -- $(echo $in_date | tr '.' ' ')
	echo "$(date +%s -d "$1")$2"
}
